import java.io.*;
import java.util.*;

public class MatrixMultiplication {

    public static void main(String[] args) throws IOException {
        if (args.length < 3) {
            System.err.println("Usage: java MatrixMultiplication <output_file> <matrixA_file1> <matrixA_file2> ... <matrixB_file1> <matrixB_file2> ...");
            System.exit(1);
        }

        String outputFile = args[0];

        // Separating input files into Matrix A and Matrix B
        List<String> matrixAFiles = new ArrayList<>();
        List<String> matrixBFiles = new ArrayList<>();
        boolean isMatrixA = true;

        for (int i = 1; i < args.length; i++) {
            String fileName = args[i];
            if (fileName.toLowerCase().startsWith("matrixb")) {
                isMatrixA = false;
            }
            if (isMatrixA) {
                matrixAFiles.add(fileName);
            } else {
                matrixBFiles.add(fileName);
            }
        }

        // Reading matrices from files
        Map<String, Double> matrixA = readMatrix(matrixAFiles);
        Map<String, Double> matrixB = readMatrix(matrixBFiles);

        // Determining dimensions dynamically
        int rowsA = matrixA.keySet().stream().mapToInt(k -> Integer.parseInt(k.split(",")[0])).max().orElse(-1) + 1;
        int colsA = matrixA.keySet().stream().mapToInt(k -> Integer.parseInt(k.split(",")[1])).max().orElse(-1) + 1;
        int rowsB = matrixB.keySet().stream().mapToInt(k -> Integer.parseInt(k.split(",")[0])).max().orElse(-1) + 1;
        int colsB = matrixB.keySet().stream().mapToInt(k -> Integer.parseInt(k.split(",")[1])).max().orElse(-1) + 1;

        if (colsA != rowsB) {
            System.err.println("Matrix multiplication not possible: Columns of A (" + colsA + ") must match rows of B (" + rowsB + ").");
            System.exit(1);
        }

        // Performing multiplication
        double[][] result = new double[rowsA][colsB];
        for (String keyA : matrixA.keySet()) {
            String[] indicesA = keyA.split(",");
            int rowA = Integer.parseInt(indicesA[0]);
            int colA = Integer.parseInt(indicesA[1]);

            for (String keyB : matrixB.keySet()) {
                String[] indicesB = keyB.split(",");
                int rowB = Integer.parseInt(indicesB[0]);
                int colB = Integer.parseInt(indicesB[1]);

                if (colA == rowB) {
                    result[rowA][colB] += matrixA.get(keyA) * matrixB.get(keyB);
                }
            }
        }

        // Writing the result to output file
        writeResult(result, outputFile);
    }

    private static Map<String, Double> readMatrix(List<String> files) throws IOException {
        Map<String, Double> matrix = new HashMap<>();
        for (String file : files) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length != 4) {
                        System.err.println("Invalid line format: " + line);
                        continue;
                    }
                    String matrixName = parts[0];
                    int row = Integer.parseInt(parts[1]);
                    int col = Integer.parseInt(parts[2]);
                    double value = Double.parseDouble(parts[3]);

                    matrix.put(row + "," + col, value);
                }
            }
        }
        return matrix;
    }

    private static void writeResult(double[][] result, String outputFile) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
            for (int i = 0; i < result.length; i++) {
                for (int j = 0; j < result[i].length; j++) {
                    if (result[i][j] != 0.0) {
                        bw.write(i + "," + j + "," + result[i][j]);
                        bw.newLine();
                    }
                }
            }
        }
        System.out.println("Result written to: " + outputFile);
    }
}
