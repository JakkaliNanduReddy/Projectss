import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.HashMap;

public class MatrixMultiplicationReducer extends Reducer<Text, Text, Text, Text> {

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        HashMap<Integer, Double> matrixA = new HashMap<>();
        HashMap<Integer, Double> matrixB = new HashMap<>();

        for (Text value : values) {
            String[] tokens = value.toString().split(",");
            String matrixName = tokens[0];
            int index = Integer.parseInt(tokens[1]);
            double val = Double.parseDouble(tokens[2]);

            if (matrixName.equals("A")) {
                matrixA.put(index, val);
            } else if (matrixName.equals("B")) {
                matrixB.put(index, val);
            }
        }

        // Compute the dot product for C[i][k]
        double sum = 0.0;
        for (int j : matrixA.keySet()) {
            if (matrixB.containsKey(j)) {
                sum += matrixA.get(j) * matrixB.get(j);
            }
        }

        // Emit the result
        context.write(key, new Text(String.valueOf(sum)));
    }
}
