import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class MatrixMultiplicationMapper extends Mapper<Object, Text, Text, Text> {

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String[] tokens = value.toString().split(",");
        String matrixName = tokens[0];
        int row = Integer.parseInt(tokens[1]);
        int col = Integer.parseInt(tokens[2]);
        double val = Double.parseDouble(tokens[3]);

        int matrixASize = context.getConfiguration().getInt("matrixA.cols", 0);
        int matrixBSize = context.getConfiguration().getInt("matrixB.rows", 0);

        if (matrixName.equals("A")) {
            // Emit (i, k) as key and "A,j,value" as value
            for (int k = 0; k < matrixASize; k++) {
                context.write(new Text(row + "," + k), new Text("A," + col + "," + val));
            }
        } else if (matrixName.equals("B")) {
            // Emit (i, k) as key and "B,j,value" as value
            for (int i = 0; i < matrixBSize; i++) {
                context.write(new Text(i + "," + col), new Text("B," + row + "," + val));
            }
        }
    }
}
